package sistema.unicsul;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ListarController {

    private final SistemaUnicsul sistema;

    public ListarController(SistemaUnicsul sistema) {
        this.sistema = sistema;
    }

    @GetMapping("/listar")
    public String listar(
            @RequestParam(required = false) String campus,
            Model model) {

        if (campus != null && !campus.isEmpty()) {

            List<String> alunos =
                    sistema.listarAlunosCampus(campus);

            model.addAttribute("alunos", alunos);
            model.addAttribute("campus", campus);
        }

        return "lista";
    }
}