package sistema.unicsul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaUnicsulApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaUnicsulApplication.class, args);
	}

}
