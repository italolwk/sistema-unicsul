package sistema.unicsul;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LocalizarController {

    private final SistemaUnicsul sistema;

    public LocalizarController(SistemaUnicsul sistema) {
        this.sistema = sistema;
    }

    // Abrir tela de localização
    @GetMapping("/localizar")
    public String localizar() {
        return "localizar";
    }

    // Pesquisar aluno
    @PostMapping("/localizar")
    public String pesquisar(
            @RequestParam String nome,
            Model model) {

        String campus = sistema.localizarAluno(nome);

        if (campus != null) {

            model.addAttribute(
                    "mensagem",
                    "Aluno encontrado!"
            );

            model.addAttribute(
                    "nome",
                    nome
            );

            model.addAttribute(
                    "campus",
                    campus
            );

            model.addAttribute(
                    "tipoMensagem",
                    "sucesso"
            );

        } else {

            model.addAttribute(
                    "mensagem",
                    "Aluno não localizado."
            );

            model.addAttribute(
                    "tipoMensagem",
                    "erro"
            );
        }

        return "localizar";
    }
}