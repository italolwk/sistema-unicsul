package sistema.unicsul;

public class No {

    public String nome;
    public No esquerda;
    public No direita;

    public No(String nome) {
        this.nome = nome;
        this.esquerda = null;
        this.direita = null;
    }
}