package sistema.unicsul;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CadastroController {

    private final SistemaUnicsul sistema;

    public CadastroController(SistemaUnicsul sistema) {
        this.sistema = sistema;
    }

    // Abrir tela de cadastro
    @GetMapping("/cadastro")
    public String cadastro() {
        return "cadastro";
    }

    // Receber os dados do formulário
    @PostMapping("/cadastro")
    public String cadastrar(
            @RequestParam String nome,
            @RequestParam String campus,
            Model model) {

        boolean cadastrado = sistema.cadastrarAluno(nome, campus);

        if (cadastrado) {

            model.addAttribute(
                    "mensagem",
                    "Aluno cadastrado com sucesso!"
            );

            model.addAttribute(
                    "tipoMensagem",
                    "sucesso"
            );

        } else {

            model.addAttribute(
                    "mensagem",
                    "Este aluno já está cadastrado em algum campus."
            );

            model.addAttribute(
                    "tipoMensagem",
                    "erro"
            );
        }

        return "cadastro";
    }
}