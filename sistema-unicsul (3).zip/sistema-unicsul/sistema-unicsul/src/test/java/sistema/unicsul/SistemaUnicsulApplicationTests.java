package sistema.unicsul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaUnicsulApplicationTests {

	@Test
	void contextLoads() {
	}

}
